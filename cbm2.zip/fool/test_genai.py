"""Quick test with google-generativeai"""
import google.generativeai as genai

api_key = "AIzaSyBGP-RgJW0e61jH19-Cy5ZK3_UtX9hHm4M"

genai.configure(api_key=api_key)

models_to_try = [
    "gemini-2.0-flash-exp",
    "gemini-1.5-flash",
    "gemini-1.5-flash-latest",
    "gemini-pro"
]

print("Testing with google-generativeai library...\n")

for model_name in models_to_try:
    try:
        print(f"Trying: {model_name}")
        model = genai.GenerativeModel(model_name)
        response = model.generate_content("Say hello in one word")
        print(f"✅ SUCCESS! Response: {response.text}\n")
        break
    except Exception as e:
        print(f"❌ Failed: {str(e)[:150]}\n")
