"""
AI Client for AURA Agentic App Creator
Configured to use Google Gemini Flash
"""

import google.generativeai as genai


class ModelsWrapper:
    """Wrapper to match the expected interface"""
    def __init__(self, model):
        self.model = model
    
    def generate_content(self, model, contents):
        """Generate content matching the expected interface"""
        response = self.model.generate_content(contents)
        return response


class AIClient:
    """Client for interacting with Google Gemini API"""
    
    def __init__(self):
        # API key configured directly
        self.api_key = "AIzaSyDgrzaLkEyK7ajpx7s76Jrq5jumSOrlkbw"
        
        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY not configured.\n"
                "Please set your API key in ai_client.py"
            )
        
        # Configure the Gemini API
        genai.configure(api_key=self.api_key)
        
        # Use Gemini 2.5 Flash model
        self.model = "models/gemini-2.5-flash"
        self._genai_model = genai.GenerativeModel(self.model)
        
        # Create wrapper to match expected interface
        self.client = type('obj', (object,), {
            'models': ModelsWrapper(self._genai_model)
        })()
        
        print(f"✅ AI Client initialized with model: {self.model}")


# Global instance
ai_client = AIClient()
