"""Test with detailed error output"""
import google.generativeai as genai
import sys

api_key = "AIzaSyDgrzaLkEyK7ajpx7s76Jrq5jumSOrlkbw"

print(f"Python version: {sys.version}")
print(f"API Key (first 20 chars): {api_key[:20]}...")

try:
    genai.configure(api_key=api_key)
    print("✅ API configured")
    
    # List available models
    print("\nAttempting to list models...")
    for m in genai.list_models():
        print(f"  - {m.name}")
        if 'gemini' in m.name.lower():
            print(f"    Trying this model...")
            model = genai.GenerativeModel(m.name)
            response = model.generate_content("Hello")
            print(f"    ✅ SUCCESS! Response: {response.text}")
            break
            
except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()
