"""Simple API test"""
import traceback
from google import genai

api_key = "AIzaSyBGP-RgJW0e61jH19-Cy5ZK3_UtX9hHm4M"

try:
    client = genai.Client(api_key=api_key)
    print("Client created successfully")
    
    # Try gemini-1.5-flash-latest
    response = client.models.generate_content(
        model="gemini-1.5-flash-latest",
        contents="Say hello"
    )
    print(f"Success! Response: {response.text}")
    
except Exception as e:
    print(f"Error: {e}")
    traceback.print_exc()
