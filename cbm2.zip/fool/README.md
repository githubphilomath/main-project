# AURA Agentic App Creator

An autonomous Python GUI app generator powered by Google Gemini 2.5 Flash.

## 🚀 Quick Start

### 1. Install Required Package

```bash
pip install google-genai
```

### 2. Set Your Gemini API Key

**Get your API key:**
- Go to https://aistudio.google.com/apikey
- Create or copy your API key

**Set the environment variable (Windows):**
```bash
set GEMINI_API_KEY=your_api_key_here
```

### 3. Run the App Creator

```bash
python "app_creator (1).py"
```

## 📝 How It Works

1. **Describe your app**: Tell it what you want (e.g., "a calculator app")
2. **AI generates code**: Gemini creates a complete Python GUI app
3. **Auto-testing**: The code is tested automatically
4. **Self-fixing**: If errors occur, Gemini fixes them automatically
5. **Launch**: Your app is saved to Desktop and launched!

## 🎯 Example Usage

```python
from app_creator import create_app

# Create a calculator app
success, msg, path = create_app("a simple calculator with buttons for +, -, *, /")

# Create a to-do list app
success, msg, path = create_app("a to-do list app with add, delete, and mark complete")
```

## 📁 Output

Generated apps are saved to: `~/Desktop/AURA_Apps/`

## ⚙️ Configuration

- **Model**: Gemini 2.5 Flash (`gemini-2.0-flash-exp`)
- **Max Retries**: 3 attempts to fix errors
- **GUI Framework**: tkinter (built-in, no installation needed)

## 🔧 Troubleshooting

**"GEMINI_API_KEY not found"**
- Make sure you set the environment variable in your current terminal session
- Verify with: `echo %GEMINI_API_KEY%`

**"AI client not available"**
- Install the package: `pip install google-genai`
- Check your API key is valid

## 📦 Dependencies

- Python 3.7+
- google-genai
- tkinter (included with Python)
