"""Simple direct test"""
import google.generativeai as genai

genai.configure(api_key="AIzaSyDgrzaLkEyK7ajpx7s76Jrq5jumSOrlkbw")

try:
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content("Say hello")
    print(f"✅ SUCCESS! Response: {response.text}")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
