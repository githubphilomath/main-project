# 🚀 How to Run AURA Agentic App Creator

## Quick Start (3 Simple Steps)

### Step 1: Open Terminal
Open PowerShell or Command Prompt in the project folder:
```bash
cd c:\Users\sreya\Downloads\fool
```

### Step 2: Run the App Creator
```bash
python "app_creator (1).py"
```

### Step 3: Watch the Magic! ✨
The app will:
1. Generate a calculator app using Gemini AI
2. Test it automatically
3. Save it to your Desktop (`C:\Users\sreya\Desktop\AURA_Apps\`)
4. Launch the app automatically!

---

## 🎯 Creating Custom Apps

### Method 1: Edit the Script
Open `app_creator (1).py` and change line 350:

```python
# Change this line (line 350):
success, msg, path = create_app("a simple calculator with buttons for +, -, *, /")

# To whatever you want, for example:
success, msg, path = create_app("a to-do list app with add, delete, and mark complete")
```

Then run:
```bash
python "app_creator (1).py"
```

### Method 2: Use Python Interactively
```bash
python
```

Then in the Python shell:
```python
from app_creator import create_app

# Create different apps:
create_app("a stopwatch timer with start, stop, and reset buttons")
create_app("a notepad text editor with save and load")
create_app("a color picker with RGB sliders")
create_app("a BMI calculator")
create_app("a password generator")
```

### Method 3: Create a Custom Script
Create a new file `my_apps.py`:

```python
from app_creator import create_app

# Create multiple apps at once
apps = [
    "a countdown timer",
    "a random number generator",
    "a unit converter for temperature",
    "a simple drawing canvas"
]

for app_description in apps:
    print(f"\n{'='*60}")
    print(f"Creating: {app_description}")
    print(f"{'='*60}")
    success, msg, path = create_app(app_description)
    if success:
        print(f"✅ {msg}")
    else:
        print(f"❌ Failed: {msg}")
```

Then run:
```bash
python my_apps.py
```

---

## 📝 App Ideas to Try

### Productivity Apps
- `"a pomodoro timer with 25-minute work sessions"`
- `"a habit tracker with checkboxes"`
- `"a simple expense tracker"`

### Fun Apps
- `"a dice roller for board games"`
- `"a magic 8-ball fortune teller"`
- `"a random quote generator"`

### Utility Apps
- `"a currency converter"`
- `"a tip calculator for restaurants"`
- `"a password strength checker"`

### Games
- `"a number guessing game"`
- `"a rock paper scissors game"`
- `"a tic-tac-toe game"`

---

## 🔧 Configuration

### Your Current Setup
- ✅ **API Key:** Configured for Gemini 2.5 Flash
- ✅ **Model:** `models/gemini-2.5-flash`
- ✅ **Output Folder:** `C:\Users\sreya\Desktop\AURA_Apps\`
- ✅ **Max Retries:** 3 attempts to fix errors
- ✅ **Auto-install:** Automatically installs missing packages

### To Change the Output Folder
Edit line 18 in `app_creator (1).py`:
```python
APPS_DIR = Path.home() / "Desktop" / "AURA_Apps"
# Change to:
APPS_DIR = Path("C:/MyApps")  # or any folder you want
```

---

## 🐛 Troubleshooting

### "AI client not available"
- Make sure `ai_client.py` is in the same folder
- Check that your API key is set correctly

### "Failed to generate initial code"
- Check your internet connection
- Verify your API key is valid at https://aistudio.google.com/apikey

### App doesn't launch
- Check `C:\Users\sreya\Desktop\AURA_Apps\` for the generated file
- Run it manually: `python "C:\Users\sreya\Desktop\AURA_Apps\your_app.py"`

---

## 📁 File Structure

```
c:\Users\sreya\Downloads\fool\
├── app_creator (1).py    # Main app creator
├── ai_client.py          # Gemini API configuration
├── HOW_TO_RUN.md        # This guide
└── README.md            # Project overview

C:\Users\sreya\Desktop\AURA_Apps\
└── simple_calculator_with.py  # Your generated apps appear here
```

---

## 💡 Pro Tips

1. **Be Specific:** The more detailed your description, the better the app
   - ❌ "a calculator"
   - ✅ "a scientific calculator with sin, cos, tan, and square root"

2. **Keep It Simple:** Start with simple apps and build up
   - The AI works best with single-purpose GUI apps
   - Complex apps may need manual refinement

3. **Iterate:** If the first version isn't perfect, try again with a more detailed description

4. **Save Your Favorites:** Copy good apps to a separate folder for safekeeping

---

## 🎉 You're All Set!

Just run:
```bash
python "app_creator (1).py"
```

And start creating amazing apps! 🚀
