"""
Quick test to verify Gemini API connection
"""

from google import genai

# Your API key
api_key = "AIzaSyBGP-RgJW0e61jH19-Cy5ZK3_UtX9hHm4M"

# Initialize client
client = genai.Client(api_key=api_key)

# Try different model names
models_to_try = [
    "gemini-2.0-flash-exp",
    "gemini-2.0-flash",
    "gemini-1.5-flash",
    "gemini-1.5-flash-latest",
    "gemini-pro"
]

print("Testing Gemini API connection...\n")

for model_name in models_to_try:
    try:
        print(f"Trying model: {model_name}")
        response = client.models.generate_content(
            model=model_name,
            contents="Say 'Hello!' in one word"
        )
        print(f"✅ SUCCESS with {model_name}")
        print(f"Response: {response.text}\n")
        break
    except Exception as e:
        print(f"❌ Failed: {str(e)[:100]}\n")
